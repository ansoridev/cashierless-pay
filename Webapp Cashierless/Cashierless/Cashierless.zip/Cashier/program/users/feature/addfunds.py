from django.shortcuts import render, redirect
from .... import models as db
from . import home

def main_controller(request):
    return views(request) if request.session.get('email', '') else redirect('/signin/')

def detail_controller(request, id):
    return detail(request, id) if request.session.get('email', '') else redirect('/signin/')

def history_controller(request):
    return history(request) if request.session.get('email', '') else redirect('/signin/')

def views(request):
    acc = db.User.objects.filter(email=request.session.get('email', ''))
    home.checkSession(acc)
    
    context = {
        "acc": acc[0],
        "paymentoto": db.PaymentMethod.objects.filter(type="OTOMATIS"),
        "paymentman": db.PaymentMethod.objects.filter(type="MANUAL")
    }
    return render(request, 'addfunds.html', context=context)

def detail(request, id):
    return

def history(request):
    return