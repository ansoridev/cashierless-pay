from django.apps import AppConfig


class CashierConfig(AppConfig):
    name = 'Cashier'
